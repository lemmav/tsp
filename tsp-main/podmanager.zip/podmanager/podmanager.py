import string, yaml
import os
import sys
from select import select
from flask import Flask, g, request, session, render_template, abort
from flask.helpers import url_for
import random, atexit
from datetime import timedelta, datetime, timezone
import requests, json
import re, sqlite3
from werkzeug.utils import redirect
from kubernetes import client,config,utils

with open('./init.json', 'r', encoding='utf-8') as fh: #открываем файл на чтение
    algorithms = json.load(fh) #загружаем из файла данные в словарь dat
with open('./initcontainers.json', 'r', encoding='utf-8') as f: #открываем файл на чтение
    containers = json.load(f) #загружаем из файла данные в словарь dat

server = Flask(__name__)

urltoip = {}
waitingpods={}
# yamltodict={}
podcounter = 0



def fromYamltoDict(algorithm,counter):
    with open("ymls/"+algorithm+".yml", "r") as file:
        data = yaml.load(file, Loader=yaml.FullLoader)

        data['metadata']['name'] = containers[algorithm]+"-"+str(counter)
        data['metadata']['labels']['app'] = containers[algorithm]+"-"+str(counter)
        data['spec']['containers'][0]['name']=containers[algorithm]
        data['spec']['containers'][0]['image']="docker.io/lemmav/"+containers[algorithm]
        data['spec']['containers'][0]['ports'][0]['containerPort']=int(algorithms[algorithm][1:])
    return data
        

def createPodReturnIP(algorithm):
    global podcounter
    # config.load_kube_config()
    config.load_incluster_config()
    k8s_client = client.ApiClient()
    # yaml_file = 'ymls/'+algorithm+".yml"
    yamltodict =  fromYamltoDict(algorithm,podcounter)
    objects = utils.create_from_dict(k8s_client, yamltodict)
    # objects = utils.create_from_yaml(k8s_client,yaml_file,verbose=True)
    podcounter += 1
    return objects[0].status.pod_ip

def fillWaitingPods():
    for algorithm in algorithms.keys():
        waitingpods[algorithm] = createPodReturnIP(algorithm)

fillWaitingPods()

# checkdb делает запрос на сервер podmanager, т.е. post-запрос
# podmanager в свою очерередь должен позволять по get-запросу собирать данные с него
@server.route("/",methods=['POST'])
def main():
    if podcounter<=5:
        url = request.args.get('url')
        algorithm = request.args.get('algorithm')
        graph = request.data
        podip = waitingpods[algorithm]
        requests.post(podip+algorithms[algorithm]+"/graph", data=graph)

        urltoip[url] = podip
        
        waitingpods[algorithm] = createPodReturnIP(algorithm) # TODO: добавить создание пода заранее
        # Т.е. необходимо чтобы был список ожидающих подов, запрос отправлялся на старый под, а на его место создавался новый
        
        
        return '1'
    else:
        return '0'

@server.route("/progress",methods=['GET'])
def progress():
    url = request.args.get('url')
    algorithm = request.args.get('algorithm')
    return requests.get(urltoip[url]+algorithms[algorithm]+'/progress').text

@server.route("/result",methods=['GET'])
def result():
    url = request.args.get('url')
    algorithm = request.args.get('algorithm')
    return requests.get(urltoip[url]+algorithms[algorithm]+'/result').text